package BeenzManagement;

public interface Request {
    void execute();
    void undo();
}

package MicropaymentManagementSystem;

public interface MicroPaymentInterface {
    String getProductName();
    void setProductName(String productName);
}


package InformationManagement;

import java.util.Date;

public class OpenedDocument extends Information{
	
	//attributes
	Date onDate;

}
